#'lab3AICKB: A package for creating a special FUNCTION.
#'
#'
#'@docType package 
#'@name lab3AICKB
#'@description for lab3.
#'
NULL
