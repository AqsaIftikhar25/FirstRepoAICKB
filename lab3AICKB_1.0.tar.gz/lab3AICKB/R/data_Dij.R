#' dijkstra Algorithm
#'
#' @name dijkstra Algorithm
#'
#' @description The algorithm takes a graph and an initial node and calculates the shortest path from the
#' initial node to every other node in the graph.
#'
#' @param a v1 number.
#' @param b v2 number.
#' @param b w number.
#'
#'
#'@references see\url{http://www.diamondse.info/} for more details.
#'
"wiki_graph"